<div dir="rtl">
<h1> مسار بناء متجر إلكتروني </h1>
<p>الشيفرة المصدرية الخاصة بمسار بناء متجر إلكتروني ضمن دورة "تطوير واجهات المستخدم" المقدمة من أكاديمية حسوب <br><a href="https://academy.hsoub.com/learn/front-end-web-development/">دورة تطوير واجهات المستخدم</a>
</p>
<ul>
<li>لتثبيت الحزم <code>npm install</code></li>
<li>لتشغيل التطبيق في بيئة التطوير <code>npm run serve</code></li>
<li>لبناء التطبيق <code>npm run build</code></li>
</ul>
<div>
</div>
</div> 
